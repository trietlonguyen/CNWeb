@extends('layouts.app')

@section('content')
	<div class="card">
		<div class="card-header">Chi tiết sản phẩm</div>
		<div class="card-body">
			@if(empty($chitietsp))
			<p><a href="{{ url('/chitietsp/them/'.$sanpham['id']) }}" class="btn btn-primary"><i class="fal fa-plus"></i> Thêm mới</a></p>
			@endif
			<table class="table table-bordered table-sm">
				<thead>

					<tr>
						<th class="w-5">STT</th>
						<th class="w-10">Tên Sản Phẩm</th>
						<th>Màn hình</th>
						<th class="w-15">Hệ điều hành</th>
						<th class="w-15">Camera sau</th>
						<th class="w-15">Camera trước</th>
						<th class="w-15">CPU</th>
						<th class="w-15">RAM</th>
						<th class="w-15">Bộ nhớ trong</th>
						<th class="w-15">Thẻ nhớ</th>
						<th class="w-15">SIM</th>
						<th class="w-15">PIN</th>
						<th class="w-15">Sạc</th>
						<th class="w-15">Tai Nghe</th>
						<th class="w-15">Ngày Sửa</th>
						<th class="w-15">Ngày Xóa</th>
						<th class="w-5">Sửa</th>
						<th class="w-5">Xóa</th>
					</tr>
				</thead>
				<tbody>
					
						<tr>
							<td></td>
							<td>{{ $chitietsp['sanpham_id'] }}</td>
							
							<td>{{ $chitietsp['manhinh'] }}</td>
							<td>{{ $chitietsp['os'] }}</td>
							<td>{{ $chitietsp['camera_sau'] }}</td>
							<td>{{ $chitietsp['camera_truoc'] }}</td>
							<td>{{ $chitietsp['cpu'] }}</td>
							<td>{{ $chitietsp['ram'] }}</td>
							<td>{{ $chitietsp['bonhotrong'] }}</td>
							<td>{{ $chitietsp['thenho'] }}</td>
							<td>{{ $chitietsp['sim'] }}</td>
							<td>{{ $chitietsp['pin'] }}</td>
							<td>{{ $chitietsp['pk_sac'] }}</td>
							<td>{{ $chitietsp['pk_tainghe'] }}</td>
							<td>{{ $chitietsp['created_at'] }}</td>
							<td>{{ $chitietsp['updated_at'] }}</td>
							<td class="text-center"><a href="{{ url('/chitietsp/sua/' . $sanpham['id']) }}"><i class="fal fa-edit"></i></a></td>
							<td class="text-center"><a href="{{ url('/chitietsp/xoa/' . $sanpham['id']) }}"><i class="fal fa-trash-alt text-danger"></i></a></td>
						</tr>
									</tbody>
			</table>
		</div>
	</div>
@endsection