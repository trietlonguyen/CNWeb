

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header">Chi tiết sản phẩm</div>
		<div class="card-body">
			<?php if(empty($chitietsp)): ?>
			<p><a href="<?php echo e(url('/chitietsp/them/'.$sanpham['id'])); ?>" class="btn btn-primary"><i class="fal fa-plus"></i> Thêm mới</a></p>
			<?php endif; ?>
			<table class="table table-bordered table-sm">
				<thead>

					<tr>
						<th class="w-5">STT</th>
						<th class="w-10">Tên Sản Phẩm</th>
						<th>Màn hình</th>
						<th class="w-15">Hệ điều hành</th>
						<th class="w-15">Camera sau</th>
						<th class="w-15">Camera trước</th>
						<th class="w-15">CPU</th>
						<th class="w-15">RAM</th>
						<th class="w-15">Bộ nhớ trong</th>
						<th class="w-15">Thẻ nhớ</th>
						<th class="w-15">SIM</th>
						<th class="w-15">PIN</th>
						<th class="w-15">Sạc</th>
						<th class="w-15">Tai Nghe</th>
						<th class="w-15">Ngày Sửa</th>
						<th class="w-15">Ngày Xóa</th>
						<th class="w-5">Sửa</th>
						<th class="w-5">Xóa</th>
					</tr>
				</thead>
				<tbody>
					
						<tr>
							<td></td>
							<td><?php echo e($chitietsp['sanpham_id']); ?></td>
							
							<td><?php echo e($chitietsp['manhinh']); ?></td>
							<td><?php echo e($chitietsp['os']); ?></td>
							<td><?php echo e($chitietsp['camera_sau']); ?></td>
							<td><?php echo e($chitietsp['camera_truoc']); ?></td>
							<td><?php echo e($chitietsp['cpu']); ?></td>
							<td><?php echo e($chitietsp['ram']); ?></td>
							<td><?php echo e($chitietsp['bonhotrong']); ?></td>
							<td><?php echo e($chitietsp['thenho']); ?></td>
							<td><?php echo e($chitietsp['sim']); ?></td>
							<td><?php echo e($chitietsp['pin']); ?></td>
							<td><?php echo e($chitietsp['pk_sac']); ?></td>
							<td><?php echo e($chitietsp['pk_tainghe']); ?></td>
							<td><?php echo e($chitietsp['created_at']); ?></td>
							<td><?php echo e($chitietsp['updated_at']); ?></td>
							<td class="text-center"><a href="<?php echo e(url('/chitietsp/sua/' . $sanpham['id'])); ?>"><i class="fal fa-edit"></i></a></td>
							<td class="text-center"><a href="<?php echo e(url('/chitietsp/xoa/' . $sanpham['id'])); ?>"><i class="fal fa-trash-alt text-danger"></i></a></td>
						</tr>
									</tbody>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Wamp\www\CNWeb_triet\CNWeb\resources\views/chitietsp/danhsach.blade.php ENDPATH**/ ?>