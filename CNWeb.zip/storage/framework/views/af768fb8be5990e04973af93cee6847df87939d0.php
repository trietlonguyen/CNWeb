[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH Z:\wamp\www\qlsv_v3.0\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>