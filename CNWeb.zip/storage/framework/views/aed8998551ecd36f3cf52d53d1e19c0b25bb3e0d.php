<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH Z:\wamp\www\qlsv_v3.0\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>