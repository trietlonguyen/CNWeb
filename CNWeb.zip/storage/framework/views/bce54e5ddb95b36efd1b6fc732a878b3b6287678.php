<?php echo e($slot); ?>

<?php /**PATH Z:\wamp\www\qlsv_v3.0\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>